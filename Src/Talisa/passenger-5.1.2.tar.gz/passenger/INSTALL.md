# Installing Phusion Passenger

Please read README.md for installation instructions.

If you're having trouble installing Phusion Passenger, please refer to [the documentation](https://www.phusionpassenger.com/).

Documentation and support resources are also available on [the website](https://www.phusionpassenger.com/support).
